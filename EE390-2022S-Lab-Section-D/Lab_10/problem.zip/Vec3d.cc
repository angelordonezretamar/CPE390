#include "Vec3d.hh"
#include <cmath>

/* 
Angel Tomas Ordonez Retamar
Lab 10
I pledge my honor that I have abided by the Stevens Honor System
*/

Vec3d operator +(const Vec3d& a, const Vec3d& b) {
	return Vec3d(a.x+b.x, a.y+b.y, a.z+b.z);
}

Vec3d operator -(const Vec3d& a, const Vec3d& b) {
	return Vec3d(a.x+b.x, a.y+b.y, a.z+b.z);
}

double Vec3d::mag() const {
	return sqrt(x*x + y*y + z*z);
}
